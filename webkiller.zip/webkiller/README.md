# WebKiller

Tool Information Gathering Write With Python.


## PreView
<pre>
██╗    ██╗███████╗██████╗ ██╗  ██╗██╗██╗     ██╗     ███████╗██████╗ 
██║    ██║██╔════╝██╔══██╗██║ ██╔╝██║██║     ██║     ██╔════╝██╔══██╗
██║ █╗ ██║█████╗  ██████╔╝█████╔╝ ██║██║     ██║     █████╗  ██████╔╝
██║███╗██║██╔══╝  ██╔══██╗██╔═██╗ ██║██║     ██║     ██╔══╝  ██╔══██╗
╚███╔███╔╝███████╗██████╔╝██║  ██╗██║███████╗███████╗███████╗██║  ██║
 ╚══╝╚══╝ ╚══════╝╚═════╝ ╚═╝  ╚═╝╚═╝╚══════╝╚══════╝╚══════╝╚═╝  ╚═╝
====================================================================
**                    WebSite : UltraSec.org                      **
**                    Channel : @UltraSecurity                    **
**                 Developers : Ashkan Moghaddas , Milad Ranjbar  **
**               Team Members : Abolfaz Hajizadeh , MrQadir       **
**                                                                **
====================================================================

    1 - Reverse IP With HackTarget
    2 - Reverse IP With YouGetSignal
    3 - Geo IP Lookup
    4 - Whois
    5 - Bypass CloudFlare
    6 - DNS Lookup
    7 - Find Shared DNS
    8 - Show HTTP Header
    9 - Port Scan
    10 - CMS Scan
    11 - Page Admin Finder
    12 - Robots.txt
    13 - Traceroute
    14 - Honeypot Detector
    15 - Ping
    16 - All
    17 - Exit
    
Enter : 
</pre>


## Operating Systems Tested
- Kali Linux 2018.2
- Windows 10


## Install
```bash
git clone https://github.com/ultrasecurity/webkiller.git
cd webkiller
pip install -r requirements.txt
python webkiller.py 
```

## ScreenShot
![webkiller](https://user-images.githubusercontent.com/34939571/42339890-a8da008c-80a3-11e8-87c1-dcf5e0648203.png)


### Thanks to
    Ashkan Moghaddas - Ultra Security Team Leader
    Abolfazl Hajizadeh - Ultra Security Team Programmer
    Milad Ranjbar -  Ultra Security Team Programmer
    MrQadir - Team Member 

### Contact us
- WebSite Ultra Security Team : https://ultrasec.org
- Channel Telegram : https://t.me/UltraSecurity
